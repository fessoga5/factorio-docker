require("tile_data")
require("points")
require("config")

script.on_event(defines.events.on_tick, function(event)
  check_end_of_round()
  check_chests()
  check_set_areas()
  check_clear_entities()
  check_start_setting_entities()
  check_start_set_areas()
  check_start_round()
  check_popup_removal()
  update_gui()
  try_to_check_victory()
end)

--So people don't place entities/ghosts outside their area
script.on_event(defines.events.on_built_entity, function(event)
  local entity = event.created_entity
  local position = entity.position
  local force = entity.force
  local origin = force.get_spawn_position(entity.surface)
  local max_distance = 45
  if origin.x + max_distance < position.x or
     origin.x - max_distance > position.x or
     origin.y + max_distance < position.y or
     origin.y - max_distance > position.y then
    entity.destroy()
  end
end)

script.on_event(defines.events.on_gui_click, function(event)
  local player = game.players[event.player_index]
  local gui = event.element
  if gui.name == "spectate" then
    if player.force == game.forces.spectators then
      player.force = game.forces.player
      player.print({"left-spectators"})
      destroy_spectate_option(player)
      create_spectate_option(player)
    else
      player.force = game.forces.spectators
      player.print({"joined-spectators"})
      destroy_spectate_option(player)
      create_spectate_option(player)
    end
  elseif gui.name == "toggle_leaderboard" then
    toggle_leaderboards(player)
  end
end)

script.on_event(defines.events.on_player_created, function(event)
  local player = game.players[event.player_index]
  set_spectator(player)
  update_end_timer(player)
  update_begin_timer(player)
  reset_task_table(player)
  init_leaderboard(player)
end)

script.on_event(defines.events.on_player_joined_game, function(event)
  local player = game.players[event.player_index]
  reset_task_table(player)
  if player.force.name ~= "spectators" then
    if global.start_round_tick then
      set_spectator(player)
    else
      local player_on_team = false
      for k, check_player in pairs (global.online_players) do
        if player == check_player then
          player_on_team = true
          break
        end
      end

      if not player_on_team then
        table.insert(global.online_players, player)
        set_player(player, #global.online_players)
        give_starting_inventory(player)
      end

    end
    update_end_timer(player)
    update_begin_timer(player)
  end
  toggle_leaderboards(player)
  toggle_leaderboards(player)
  if global.end_round_tick then
    update_winners_list(player)
  end
end)

script.on_event(defines.events.on_player_left_game, function(event)
  local player = game.players[event.player_index]
  reset_task_table(player)
end)


script.on_init(function ()
  setup_config()
  global.online_players = {}
  global.winners = {}
  global.points = {}
  global.recent_points = {}
  global.chests = {}
  global.round_number = 0
  global.recent_round_number = 0
  generate_technology_list()
  create_teams()
  fill_leaderboard()
  game.surfaces[1].always_day = true
end)

function select_from_probability_table(probability_table)
  local roll_max = 0
  for _, item in pairs(probability_table) do
    roll_max = roll_max + item.probability
  end

  local roll_value = math.random(0, roll_max - 1)
  for _, item in pairs(probability_table) do
    roll_value = roll_value - item.probability
    if (roll_value < 0) then
      return item.value
    end
  end
end

function select_inventory() return select_from_probability_table(global.inventory_probabilities) end
function select_equipment() return select_from_probability_table(global.equipment_probabilities) end
function select_challange_type() return select_from_probability_table(global.challange_type_probabilities) end

function start_challenge()
  global.round_number = global.round_number + 1
  if global.recent_round_number == global.recent_round_count then
    global.recent_round_number = 0
    global.recent_points = {}
  end
  global.recent_round_number = global.recent_round_number + 1
  global.round_timer_value = game.tick
  global.winners = {}

  global.round_inventory = select_inventory()
  global.round_equipment = select_equipment()
  global.challenge_type = select_challange_type()

  if global.challenge_type == "production" then
    generate_production_task()
  elseif global.challenge_type == "research" then
    generate_research_task()
  end
end

function create_teams()
  for k, force in pairs(global.force_list) do
    game.create_force(force.name)
  end
  for k, force in pairs (game.forces) do
    for j, friend in pairs (game.forces) do
      if force.name ~= friend.name then
        force.set_cease_fire(friend, true)
      end
    end
  end
  game.create_force("spectators")
end

function set_areas()
  shuffle_table(global.force_list)
  if not global.placement_grid then
    create_grid()
  end
  global.set_areas_tick = game.tick + #global.force_list + 1 -- Because we call this function during on_tick event, add 1
end

function set_teams()
  global.online_players = {}
  for k, player in pairs(game.players) do
    if player.connected and player.force ~= game.forces.spectators then
      table.insert(global.online_players, player)
    end
    if not player.connected and player.force ~= game.forces.spectators then
      player.force = game.forces.player
    end
  end
  if #global.online_players > 0 then
    global.players_per_team = math.floor((#global.online_players)^0.5)
  else
    global.players_per_team = 1
  end
  shuffle_table(global.online_players)
  for k, player in pairs (global.online_players) do
    set_player(player, k)
  end
  for k, player in pairs (global.online_players) do
    --We have to do this after all teams are assigned.
    give_starting_inventory(player)
  end

end


function init_leaderboard(player)
  if not player.gui.left.leaderboard_wrap then
    local wrap = player.gui.left.add{type = "table", name = "leaderboard_wrap", colspan = 1}
          --wrap.add{type= "button", name = "toggle_leaderboard", caption = {"toggle-leaderboard"} }
          toggle_leaderboards(player)
  end
end

function reset_leaderboard(player)
  if player.gui.left.leaderboard_wrap then
      player.gui.left.leaderboard_wrap.destroy()
      init_leaderboard(player)
  end
end


function toggle_leaderboards(player)
  if player.connected then
    if player.gui.left.leaderboard_wrap.leaderboard_child_wrap then
      player.gui.left.leaderboard_wrap.leaderboard_child_wrap.destroy()
    else
      local wrap = player.gui.left.leaderboard_wrap.add{type = "table", name = "leaderboard_child_wrap", colspan = 2}
      wrap.style.horizontal_spacing = 0
      local frame = wrap.add{type = "frame", name = "leaderboard", caption = {""}, direction = "vertical"}
      frame.add{type = "label", name = global_points, caption = {"all-time"}}
      local leaderboard_table = frame.add{type = "table", colspan = 3, name = "leaderboard_table"}
      local count = 1
      for name, points in spairs(global.points, function(t, a, b) return t[b] < t[a] end) do
        if count <= 5 then
          local this = leaderboard_table.add{type = "label", name = name.."count", caption = {"", "#", count, ""}}
          this.style.font_color = {r = 1, g = 1, b = 0.2}
          local that = leaderboard_table.add{type = "label", name = name.."name", caption = name}
          if name == player.name then
            that.style.font_color = {r = 1, g = 0.6, b = 0.1}
            player.tag = "<#"..count.."/"..points..">"
          end

          leaderboard_table.add{type = "label", name = name.."points", caption = points}
          count = count + 1
        else
          count = count + 1
          if name == player.name then
            local this = leaderboard_table.add{type = "label", name = name.."count", caption = {"", "#", count, ""}}
            this.style.font_color = {r = 1, g = 1, b = 0.2}
            local that = leaderboard_table.add{type = "label", name = name.."name", caption = name}
            if name == player.name then
              that.style.font_color = {r = 1, g = 0.6, b = 0.1}
              player.tag = "<#"..count.."/"..points..">"
            end
            leaderboard_table.add{type = "label", name = name.."points", caption = points}
          end
        end
      end
      local frame = wrap.add{type = "frame", name = "recent_leaderboard", caption = {""}, direction = "vertical"}
      frame.add{type = "label", name = global_points, caption = {"recent"}}
      local leaderboard_table = frame.add{type = "table", colspan = 3, name = "leaderboard_table"}
      local count = 1
      for name, points in spairs(global.recent_points, function(t, a, b) return t[b] < t[a] end) do
        if count <= 5 then
          local this = leaderboard_table.add{type = "label", name = name.."count", caption = {"", "#", count, ""}}
          this.style.font_color = {r = 1, g = 1, b = 0.2}
          local that = leaderboard_table.add{type = "label", name = name.."name", caption = name}
          if name == player.name then
            that.style.font_color = {r = 1, g = 0.6, b = 0.1}
          end
          leaderboard_table.add{type = "label", name = name.."recent_points", caption = points}
          count = count + 1
        else
          count = count + 1
          if name == player.name then
            local this = leaderboard_table.add{type = "label", name = name.."count", caption = {"", "#", count, ""}}
            this.style.font_color = {r = 1, g = 1, b = 0.2}
            local that = leaderboard_table.add{type = "label", name = name.."name", caption = name}
            if name == player.name then
              that.style.font_color = {r = 1, g = 0.6, b = 0.1}
            end
            leaderboard_table.add{type = "label", name = name.."points", caption = points}
          end
        end
      end
    end

  end
end


function destroy_leaderboards(player)
    if player.gui.left.leaderboard then
      player.gui.left.leaderboard.destroy()
    end
    if player.gui.left.recent_leaderboard then
      player.gui.left.recent_leaderboard.destroy()
    end
end

function set_player(player, k)
  set_spectator(player)
  local index = math.ceil(k/global.players_per_team)
  if global.force_list[index] then
    player.force = global.force_list[index].name
    set_character(player, player.force)
    local c = global.force_list[index].color
    player.color = {r = c[1], g = c[2], b = c[3], a = c[4]}
    give_equipment(player)
  else
  player.print({"couldnt-place-on-team"})
  end
end

function generate_technology_list()
  global.task_technologies = {}
  local force = game.forces.player
  for k, technology in pairs (force.technologies) do
    local include = true
    for j, ingredient in pairs (technology.research_unit_ingredients) do
      if ingredient.name == "science-pack-3" or ingredient.name == "alien-science-pack" then
      include = false
      break
      end
    end
    if technology.upgrade then
      include = false
    end
    if include then
      local name = technology.name
      table.insert(global.task_technologies, name)
    end
  end
end

function generate_research_task()
  for k, player in pairs(game.players) do
    reset_task_table(player)
  end
  global.research_task = {}
  shuffle_table(global.task_technologies)
  local number_of_techs = math.random(1, 3)
  for k = 1, number_of_techs do
    global.research_task[k] = global.task_technologies[k]
  end
  
  global.progress = {}
  for j, force in pairs (game.forces) do
    if not global.progress[force.name] then global.progress[force.name] = {} end
    for k, tech in pairs (global.research_task) do
      global.progress[force.name][tech] = 0
    end
    setup_unlocks(force)
  end
end

function setup_unlocks(force)
  local challenge_type = global.challenge_type 
  for k, technology in pairs (force.technologies) do
    technology.enabled = false
  end
  
  for i, name in pairs (global.task_technologies) do
    local technology = force.technologies[name]
    technology.enabled = true
    technology.researched = true
  end 
    
  if challenge_type == "research" then
    local technologies_to_research = {}
    for _, research_task in pairs (global.research_task) do
      technologies_to_research[research_task] = true
    end
    
    for _, research_task in pairs (global.research_task) do
      local technology = force.technologies[research_task]
      technology.researched = false
      for _, prerequisite in pairs(technology.prerequisites) do
        if not technologies_to_research[prerequisite.name] then
          prerequisite.researched = true
          prerequisite.enabled = true
        end
      end
    end
  end

  for k, recipe in pairs (force.recipes) do
    for j, disallowed in pairs (global.disabled_items) do
      if recipe.name == disallowed then
        recipe.enabled = false
      end
    end
  end
  force.set_ammo_damage_modifier("bullet", -1)
  force.set_ammo_damage_modifier("flame-thrower", -1)
  force.set_ammo_damage_modifier("capsule", -1)
  force.set_ammo_damage_modifier("cannon-shell", -1)
  force.set_ammo_damage_modifier("grenade", -1)
  force.set_ammo_damage_modifier("electric", -1)
  force.worker_robots_speed_modifier = 3
end


function check_technology_progress(force)
  for k, technology in pairs (global.research_task) do
    if force.technologies[technology].researched == false then

      local tech = force.current_research
      if tech then
        if tech.name == technology then
          global.progress[force.name][technology] = force.research_progress

        end
      end
    else
    global.progress[force.name][technology] = 100
    end
  end
end

function generate_production_task()
  for k, player in pairs(game.players) do
    reset_task_table(player)
  end
  shuffle_table(global.item_list)
  global.task_items = {}
  local number_of_items = math.random(1, global.max_count_of_production_tasks)
  local max_count = calculate_task_item_multiplayer(number_of_items)
  for k = 1, number_of_items do
    global.task_items[k] = {}
    global.task_items[k].name = global.item_list[k].name
    global.task_items[k].count = math.random(2, max_count)*global.item_list[k].count
  end


  global.progress = {}
  for j, force in pairs (game.forces) do
    if not global.progress[force.name] then global.progress[force.name] = {} end
    for k, item in pairs (global.task_items) do
      global.progress[force.name][item.name] = 0
    end
    setup_unlocks(force)
  end

end

function update_task_gui(player)
  if not global.challenge_type then return end
  if global.challenge_type == "production" then
    update_production_task_table(player)
  elseif global.challenge_type == "research" then
    update_research_task_table(player)
  end
end

function check_end_of_round()
  if game.tick ~= global.end_round_tick then return end

  global.end_round_tick = nil
  global.start_round_tick = game.tick + 60 * 60
  global.chests = nil
  global.task_items = nil
  global.progress = nil
  global.research_task = nil
  global.challenge_type = nil

  for k, player in pairs(game.players) do
    update_end_timer(player)
    update_begin_timer(player)
    player.print({"next-round-soon"})
    reset_task_table(player)
    set_spectator(player)
    create_spectate_option(player)
    if player.gui.left.winners_frame then
      player.gui.left.winners_frame.caption = {"round-winners"}
    end
  end
end

function try_to_check_victory()
  if game.tick % 60 ~= 0 then return end
  for k, force in pairs (game.forces) do
    check_victory(force)
  end
end

function update_gui()
  if game.tick % 60 ~= 0 then return end
  for k, player in pairs(game.players) do
    update_end_timer(player)
    update_begin_timer(player)
    update_task_gui(player)
  end
end

function check_popup_removal()
  if game.tick == global.remove_player_won_window_tick then
    for k, player in pairs (game.players) do
      if player.gui.center.popup_win then
        player.gui.center.popup_win.destroy()
      end
    end
  end
end

function check_start_round()
  if game.tick ~= global.start_round_tick then return end
  global.start_round_tick = nil
  game.speed = 1
  global.winners = {}
  for k, player in pairs(game.players) do
    update_winners_list(player)
    destroy_spectate_option(player)
    update_begin_timer(player)

  end
  start_challenge()
  set_teams()
end

function check_start_set_areas()
  if not global.start_round_tick then return end
  --Calculates when to start settings the areas
  if global.start_round_tick - ((#global.force_list) * 2 + ((#global.force_list) * global.ticks_to_generate_entities)) == game.tick then
    set_areas()
  end
end

function check_start_setting_entities()
  --Start setting the entities
  if not global.set_entities_tick then return end

  local index = math.ceil((global.set_entities_tick - game.tick)/global.ticks_to_generate_entities)
  if index > 0 then
    local listed = global.force_list[index]
    if listed then
      local grid_position = global.placement_grid[index]
      local force = game.forces[listed.name]
      local offset_x = grid_position[1] * 96
      local offset_y = grid_position[2] * 96
      recreate_entities(map_entities, offset_x, offset_y, force, global.ticks_to_generate_entities)
    end
  else
    global.set_entities_tick = nil
  end
end

function check_clear_entities()
  --Clear the entities in the team areas
  if not global.clear_entities_tick then return end

  local index = global.clear_entities_tick - game.tick
  if index > 0 then
    local grid_position = global.placement_grid[index]
    local X = grid_position[1] * 96
    local Y = grid_position[2] * 96
    local distance = 45
    local area = {{X-distance,Y-distance},{X+distance,Y+distance}}
    clear_map(game.surfaces[1], area)
    clear_map(game.surfaces[1], area) --Do it twice to remove items on ground after destroying transport belt
  else
    global.clear_entities_tick = nil
    global.set_entities_tick = game.tick + (#global.force_list * global.ticks_to_generate_entities)
  end
end

function check_set_areas()
  if not global.set_areas_tick then return end

  local index = global.set_areas_tick - game.tick
  if index > 0 then
    local listed = global.force_list[index]
    if listed then
      local grid_position = global.placement_grid[index]
      local force = game.forces[listed.name]
      local offset_x = grid_position[1] * 96
      local offset_y = grid_position[2] * 96
      create_tiles(map_tiles, offset_x, offset_y)
      force.set_spawn_position({offset_x, offset_y}, game.surfaces[1])
      force.rechart()
    end
  else
    global.set_areas_tick = nil
    global.clear_entities_tick = game.tick + #global.force_list
  end
end

--Checks 1 at a time
function check_chests()
  if not global.chests then return end

  local index = (game.tick % #global.chests) + 1
  local chest = global.chests[index]
  if not chest then return end

  if not chest.valid then
    table.remove(global.chests, index)
    return
  end

  if not global.task_items then return end

  for k, item in pairs (global.task_items) do
    local count = chest.get_item_count(item.name)
    if count + global.progress[chest.force.name][item.name] > item.count then
      count = item.count - global.progress[chest.force.name][item.name]
    end
    if count > 0 then
      chest.remove_item({name = item.name, count = count})
      global.progress[chest.force.name][item.name] = global.progress[chest.force.name][item.name] + count
      for k, player in pairs (game.players) do
        if player.force == chest.force then
          update_production_task_table(player)
        end
      end
    end
  end
end

function check_victory(force)
  if not global.challenge_type then return end

  for k, winners in pairs (global.winners) do
    if force == winners then
      return
    end
  end

  local challenge_type = global.challenge_type
  if challenge_type == "production" then
    local finished_tasks = 0
    for k, item in pairs (global.task_items) do
      if global.progress[force.name][item.name] >= item.count then
      finished_tasks = finished_tasks +1
      end
    end
    if finished_tasks >= #global.task_items then
      team_finished(force)
    end
  elseif challenge_type == "research" then
    check_technology_progress(force)
    local finished_tasks = 0
    for k, technology in pairs (global.research_task) do
      if global.progress[force.name][technology] == 100 then
        finished_tasks = finished_tasks + 1
      end
    end
    if finished_tasks >= #global.research_task then
      team_finished(force)
    end
  end
end

function update_research_task_table(player)
  if global.research_task then
    if global.progress[player.force.name] then
      if player.force.name == "spectators" then

        if not player.gui.left.task_frame then
          local frame = player.gui.left.add{name = "task_frame", type = "frame", direction = "vertical", caption = {"", {"round"}, "\n ", global.recent_round_number, " ", {"of"}, " " .. global.recent_round_count .. "\n"}}
          frame.style.minimal_width = 160
          frame.add{type = "label", name = "round_timer", caption = {"", {"elapsed-time"}, ": ", format_time(game.tick - global.round_timer_value), ""}}
          local tech_table = frame.add{type = "table", name = "tech_table", colspan = 1}
          for i, tech in pairs (global.research_task) do
            tech_table.add{type = "label", name = "task"..i, caption = player.force.technologies[tech].localised_name}
          end
          reset_leaderboard(player)
        else
          player.gui.left.task_frame.round_timer.caption = {"", {"elapsed-time"}, ": ", format_time(game.tick - global.round_timer_value), ""}
        end
      else
        if not player.gui.left.task_frame then
          local frame = player.gui.left.add{name = "task_frame", type = "frame", direction = "vertical", caption = {"", {"round"}, "\n ", global.recent_round_number, " ", {"of"}, " " .. global.recent_round_count .. "\n"}}
          frame.style.minimal_width = 160
          frame.add{type = "label", name = "round_timer", caption = {"", {"elapsed-time"}, ": ", format_time(game.tick - global.round_timer_value), ""}}
          local tech_table = frame.add{type = "table", name = "tech_table", colspan = 1}
          tech_table.add{type = "label", name = "task_description", caption = {"research-task"}}
          for i, tech in pairs (global.research_task) do
            tech_table.add{type = "label", name = "task"..i, caption = {"", player.force.technologies[tech].localised_name, ": ", ""}}
            tech_table.add{type = "progressbar", name = "progress"..i, size = 100}
          end
          reset_leaderboard(player)
        elseif player.gui.left.task_frame then
          player.gui.left.task_frame.round_timer.caption = {"", {"elapsed-time"}, ": ", format_time(game.tick - global.round_timer_value), ""}
          for i, tech in pairs (global.research_task) do
            if global.progress[player.force.name][tech] then
              player.gui.left.task_frame.tech_table["progress"..i].value=global.progress[player.force.name][tech]
            else
              log("Global progress nil error"..player.force.name.."  "..tech)
            end
          end
        end
      end
    end
  end
end

function create_spectate_option(player)
  if not player.gui.left.spectate then
    if player.force == game.forces.spectators then
      player.gui.left.add{type = "button", name = "spectate", caption = {"", {"unspectate"}, ""} }
    else
      player.gui.left.add{type = "button", name = "spectate", caption = {"", {"spectate"}, ""} }
    end
  end
end

function destroy_spectate_option(player)
  if player.connected then
    if player.gui.left.spectate then
      player.gui.left.spectate.destroy()
    end
  end
end

function update_production_task_table(player)
  if global.task_items then
    if global.progress[player.force.name] then
      if player.force == game.forces.spectators then
        if not player.gui.left.task_frame then
          local frame = player.gui.left.add{name = "task_frame", type = "frame", direction = "vertical", caption = {"", {"round"}, "\n ", global.recent_round_number, " ", {"of"}, " " .. global.recent_round_count .. "\n"}}
          frame.style.minimal_width = 160
          frame.style.right_padding = 0
          frame.add{type = "label", name = "round_timer", caption = {"", {"elapsed-time"}, ": ", format_time(game.tick - global.round_timer_value), ""}}
          local task_table = frame.add{type = "table", colspan = 2, name = "task_table"}
          task_table.add{type = "label", name = "task_description", caption = {"", {"production-task"}, ""}}
          task_table.add{type = "label", name = "task_description_pad", caption = ""}
          for i, item in pairs (global.task_items) do
            task_table.add{type = "label", name = "task"..i, caption = {"", game.item_prototypes[item.name].localised_name, ": "}}
            task_table.add{type = "label", name = "count"..i, caption = item.count}
          end
          reset_leaderboard(player)
        elseif player.gui.left.task_frame then
          player.gui.left.task_frame.round_timer.caption = {"", {"elapsed-time"}, ": ", format_time(game.tick - global.round_timer_value), ""}
        end
      else
        if not player.gui.left.task_frame then
          local frame = player.gui.left.add{name = "task_frame", type = "frame", direction = "vertical", caption = {"", {"round"}, "\n ", global.recent_round_number, " ", {"of"}, " " .. global.recent_round_count .. "\n"}}
          frame.style.minimal_width = 160
          frame.add{type = "label", name = "round_timer", caption = {"", {"elapsed-time"}, ": ", format_time(game.tick - global.round_timer_value), ""}}
          local task_table = frame.add{type = "table", colspan = 2, name = "task_table"}
          task_table.add{type = "label", name = "task_description", caption = {"", {"production-task"}, ""}}
          task_table.add{type = "label", name = "task_description_pad", caption = ""}
          for i, item in pairs (global.task_items) do
            task_table.add{type = "label", name = "task"..i, caption = {"", game.item_prototypes[item.name].localised_name, ": "}}
            task_table.add{type = "label", name = "count"..i, caption = {"", global.progress[player.force.name][item.name], "/", item.count}}
          end
          reset_leaderboard(player)
        elseif player.gui.left.task_frame then
          player.gui.left.task_frame.round_timer.caption = {"", {"elapsed-time"}, ": ", format_time(game.tick - global.round_timer_value), ""}
          for i, item in pairs (global.task_items) do
            if global.progress[player.force.name][item.name] then
              player.gui.left.task_frame.task_table["count"..i].caption = {"", global.progress[player.force.name][item.name], "/", item.count}
            else
              log("Global progress nil error"..player.force.name.."  "..item.name.."  "..item.count)
            end
          end
        end

      end
    end
  end
end

function pre_ending_round()

  global.end_round_tick = game.tick + 60*60*2 --2 minutes
  for k, player in pairs(game.players) do
    update_end_timer(player)
    local popup = player.gui.center.add{type = "frame", name = "popup_win", caption = {"", global.winners[1].name, " ", {"finished-task"}, ""}}
    local popup_table = popup.add{type = "table", name = "popup_table", colspan = 1}
    popup_table.add{type = "label", name = "popup_win", caption = {"end-soon"}}
    player.set_goal_description("Hi")
    player.set_goal_description("")
  end
    global.remove_player_won_window_tick = game.tick + 60*3
end

function update_end_timer(player)
  if player.connected then
    if global.end_round_tick then
      if player.gui.left.winners_frame then
        player.gui.left.winners_frame.caption = {"", {"winners"}, " - ", {"end-round"}, ": ", format_time(global.end_round_tick - game.tick)}
      end
    end
  end
end

function update_begin_timer(player)
  if player.connected then
    if global.start_round_tick then
      if not player.gui.left.pre_counter then
        local frame = player.gui.left.add{name = "pre_counter", type = "frame", direction = "horizontal", caption = {"", {"begin-round"}, " - ", format_time(global.start_round_tick - game.tick)}}
        frame.style.maximal_height = 40

      else
      player.gui.left.pre_counter.caption = {"", {"begin-round"}, " - ", format_time(global.start_round_tick - game.tick)}
      end
    else
      if player.gui.left.pre_counter then
        player.gui.left.pre_counter.destroy()
      end
    end
  end
end

function team_finished(force)
  table.insert(global.winners, force)
  local points = global.points_per_win
  for j, winning_force in pairs (global.winners) do
    if winning_force == force then
      points = math.floor(points/j)
      break
    end
  end
  local points_lua = "function give_points()\n  return\n  {\n"
  for name, points in pairs (global.points) do
    points_lua = points_lua .. "    [\""..name.."\"] = "..points..", \n";
  end
  points_lua = points_lua .. "  }\nend"
  game.write_file("points.lua", points_lua, false, 0)
  
  for k, player in pairs(game.players) do
    if player.connected then
      if player.force == force then
        set_spectator(player)
        player.print({"", {"your-team-win"}, " ", points, " ", {"points"}, "."})
        if not global.points[player.name] then
          global.points[player.name] = points
        else
          global.points[player.name] = global.points[player.name] + points
        end

        if not global.recent_points[player.name] then
          global.recent_points[player.name] = points
        else
          global.recent_points[player.name] = global.recent_points[player.name] + points
        end
      else
        player.print({"", force.name, " ", {"finished-task"}, ""})
      end
    end
  end
  if #global.winners == 1 then
    pre_ending_round()
  end

  for k, player in pairs (game.players) do
    update_winners_list(player)
    toggle_leaderboards(player)
    toggle_leaderboards(player)
  end
end

function update_winners_list(player)
  if global.winners and #global.winners ~= 0 then
    if not player.gui.left.winners_frame then
      local frame = player.gui.left.add{type = "frame", name = "winners_frame", caption = {"", {"winners"}, " - ", {"end-round"}, ": ", format_time(global.end_round_tick - game.tick)}, direction = "vertical"}
      local winners_table = frame.add{type = "table", name = "winners_table", colspan = 4}
      winners_table.add{type = "label", name = "winners_name", caption = {"name"}}
      winners_table.add{type = "label", name = "winners_players", caption = {"members"} }
      winners_table.add{type = "label", name = "winners_time" , caption = {"time"} }
      winners_table.add{type = "label", name = "winners_points" , caption = {"points"} }
    end

    for k, force in pairs(global.winners) do
      if not player.gui.left.winners_frame.winners_table[force.name] then
        local winners_table = player.gui.left.winners_frame.winners_table
        local this = winners_table.add{type = "label", name = force.name, caption = {"", "#", k, " ", force.name, " ", {"team"}}}
        local color = {r = 0.8, g = 0.8, b = 0.8, a = 0.8}
        for i, check_force in pairs (global.force_list) do
          if force.name == check_force.name then
            local c = check_force.color
            color = {r = 1 - (1 - c[1]) * 0.5, g = 1 - (1 - c[2]) * 0.5, b = 1 - (1 - c[3]) * 0.5, a = 1}
            break
          end
        end
        this.style.font_color = color

        local caption = ""
        local count = 0
        for j, player in pairs (game.players) do
          if player.force == force then
            count = count + 1
            if player.connected then
              if count == 1 then
                caption = caption..player.name
              else
                caption = caption..", "..player.name
              end
            end
          end
        end
        winners_table.add{type = "label", name = force.name.."players", caption = caption}
        winners_table.add{type = "label", name = force.name.."time", caption = format_time(game.tick - global.round_timer_value)}
        winners_table.add{type = "label", name = force.name.."points", caption = math.floor(global.points_per_win/k)}
      end
    end
  elseif player.gui.left.winners_frame then
    player.gui.left.winners_frame.destroy()
  end
end

function reset_task_table(player)
  if player.gui.left.task_frame then
    player.gui.left.task_frame.destroy()
  end
end

function set_spectator(player)
  if player.connected then
    if player.character then
      local character = player.character
      player.character = nil
      if character then
        character.destroy()
      end
      player.set_controller{type = defines.controllers.ghost}
    end
  end
end

function set_character(player, force)
  if player.connected then
    player.force = force
    local character = player.surface.create_entity{name = "player", position = player.surface.find_non_colliding_position("player", player.force.get_spawn_position(player.surface), 10, 2), force = force}
    player.set_controller{type = defines.controllers.character, character = character}
  end
end

function give_starting_inventory(player)
  if player.connected then
    if player.character and global.starting_inventories[global.round_inventory] then
      for k, item in pairs (global.starting_inventories[global.round_inventory]) do
        local count = math.ceil(item.count*(global.players_per_team/#player.force.players))
        if count > 0 then
          player.insert{name = item.name, count = count}
        end
      end
    end
  end
end

function give_equipment(player)
  if not player.connected then return end
  if not player.character then return end
  if not global.round_equipment then return end

  if global.round_equipment == "small" then
    player.insert{name = "power-armor", count = 1}
    local p_armor = player.get_inventory(5)[1].grid
    p_armor.put({name = "fusion-reactor-equipment"})
    p_armor.put({name = "exoskeleton-equipment"})
    p_armor.put({name = "personal-roboport-equipment"})
    p_armor.put({name = "personal-roboport-equipment"})
    p_armor.put({name = "personal-roboport-equipment"})
    player.insert{name="construction-robot", count = 30}
    player.insert{name="blueprint", count = 3}
    player.insert{name="deconstruction-planner", count = 1}
  end
end






function save_map_data(distance)

--This exports current map data as an array of entities and tiles
--TODO Optimise output size

local data = "tiles = \n{\n"
  for X = -distance, distance do
    for Y = -distance, distance do
      local tile = game.surfaces[1].get_tile(X, Y)
      local name = tile.name
      if name ~= "out-of-map" then
      local position = tile.position
      data = data.."  {name = \""..name.."\", position = {"..position.x..", "..position.y.."}}, \n"
      end
    end
  end
  data = data.."\n}\n\n".."entities = \n{\n"
  for k, entity in pairs (game.surfaces[1].find_entities({{-distance, -distance}, {distance, distance}})) do
    local name = entity.name
    local position = entity.position
    local direction = entity.direction
    local force = entity.force
    if entity.name == "express-loader" then
      local loader_type = entity.loader_type
      data = data.."  {name = \""..name.."\", position = {"..position.x..", "..position.y.."}, force = \""..force.name.."\", direction = "..direction..", type = \""..loader_type.."\"}, \n"
    elseif entity.type == "resource" then
      local amount = entity.amount
      data = data.."  {name = \""..name.."\", position = {"..position.x..", "..position.y.."}, amount = "..amount.."}, \n"
    else
      data = data.."  {name = \""..name.."\", position = {"..position.x..", "..position.y.."}, force = \""..force.name.."\", direction = "..direction.."}, \n"
    end
  end
  data = data.."\n}"
  game.write_file("tile_data.lua", data)
end

function clear_map(surface, area)
  if area then
    for k, entity in pairs (surface.find_entities(area)) do
      entity.destroy()
    end
  else
    for k, entity in pairs (surface.find_entities()) do
      entity.destroy()
    end
  end
end

function create_tiles(tiles, offset_x, offset_y)
if tiles then
    local offset_tiles = {}
    local tile_info = tiles[0]
    for k, tile in pairs (tiles) do
      offset_tiles[k] = {name = tile.name, position = {tile.position[1]+offset_x, tile.position[2]+offset_y}}
    end
    game.surfaces[1].set_tiles(offset_tiles, true)
  end
end

function recreate_entities(entities, offset_x, offset_y, force, duration)
  if not global.chests then global.chests = {} end

  if not entities then return end

  for k, entity in pairs (entities) do
    if k % global.ticks_to_generate_entities == game.tick % global.ticks_to_generate_entities then
      if entity.amount then
        game.surfaces[1].create_entity({name = entity.name, position = {entity.position[1]+offset_x, entity.position[2]+offset_y}, amount = entity.amount})
      elseif entity.name == "express-loader" then
        local v = game.surfaces[1].create_entity({force = force, direction = entity.direction, name = entity.name, position = {entity.position[1]+offset_x, entity.position[2]+offset_y}, type = entity.type})
        v.destructible = false
        v.minable = false
        v.rotatable = false
      elseif entity.name == "logistic-chest-passive-provider" then
        local v = game.surfaces[1].create_entity({force = force, name = entity.name, position = {entity.position[1]+offset_x, entity.position[2]+offset_y}})
        v.destructible = false
        v.minable = false
        v.rotatable = false
        table.insert(global.chests, v)
      elseif entity.name == "electric-energy-interface" then
        local v = game.surfaces[1].create_entity({force = force, name = entity.name, position = {entity.position[1]+offset_x, entity.position[2]+offset_y}})
        v.destructible = false
        v.minable = false
        v.rotatable = false
        v.power_production = 5 * 10^9
        v.power_usage = 0
        v.electric_buffer_size = 5 * 10^9
        v.energy = 2.55 * 10^9
        v.electric_output_flow_limit = 50000000
        v.electric_input_flow_limit = 50000000
      elseif entity.name == "big-electric-pole" then
        local v = game.surfaces[1].create_entity({force = force, name = entity.name, position = {entity.position[1]+offset_x, entity.position[2]+offset_y}})
        v.destructible = false
        v.minable = false
        v.rotatable = false

      else
        game.surfaces[1].create_entity({name = entity.name, position = {entity.position[1]+offset_x, entity.position[2]+offset_y}, force = force})
      end
    end
  end
end

function shuffle_table(t)
  local iterations = #t
  for i = iterations, 2, -1 do
    local j = math.random(i)
    t[i], t[j] = t[j], t[i]
  end
end

function shuffle_item_tables()
  shuffle_table(global.item_list["easy"])
  shuffle_table(global.item_list["medium"])
  shuffle_table(global.item_list["hard"])
end

function format_time(ticks)
  local seconds = ticks / 60
  local minutes = math.floor((seconds)/60)
  local seconds = math.floor(seconds - 60*minutes)
  return string.format("%d:%02d", minutes, seconds)
end

function create_grid()
  global.placement_grid = {}
  for y = -1, 2 do
    for x = -2, 1 do
      local offset = {x, y}
      table.insert(global.placement_grid, offset)
    end
  end

end

function spairs(t, order)
    -- collect the keys
    local keys = {}
    for k in pairs(t) do keys[#keys+1] = k end

    -- if order function given, sort by it by passing the table and keys a, b,
    -- otherwise just sort the keys
    if order then
        table.sort(keys, function(a, b) return order(t, a, b) end)
    else
        table.sort(keys)
    end

    -- return the iterator function
    local i = 0
    return function()
        i = i + 1
        if keys[i] then
            return keys[i], t[keys[i]]
        end
    end
end

function fill_leaderboard()
global.points = give_points()
global.recent_points = {}
  for k, player in pairs (game.players) do
    toggle_leaderboards(player)
    toggle_leaderboards(player)
  end
end
